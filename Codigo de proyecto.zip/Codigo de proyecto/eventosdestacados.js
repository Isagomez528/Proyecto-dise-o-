document.addEventListener('DOMContentLoaded', function () {
    // Definición de variables
    const languageToggle = document.querySelector('.custom-icon[alt="idioma"]');  // Ícono de idioma
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    const logoutButton = document.getElementById('logout');
    const themeToggle = document.getElementById('toggle-theme');
    const icons = document.querySelectorAll('.custom-icon');
    
    let currentLanguage = localStorage.getItem('language') || 'es';  // Idioma predeterminado
    const currentTheme = localStorage.getItem('theme') || 'light';  // Tema predeterminado

    // -----------------------------------
    // Cambio de idioma
    // -----------------------------------

    // Función para cambiar el idioma
    function changeLanguage(language) {
        const elements = document.querySelectorAll('[data-es], [data-en]');  // Selecciona todos los elementos con texto traducible
        
        elements.forEach(element => {
            const textEs = element.getAttribute('data-es');  // Texto en español
            const textEn = element.getAttribute('data-en');  // Texto en inglés

            if (language === 'en') {
                element.textContent = textEn;  // Cambia el texto al inglés
            } else {
                element.textContent = textEs;  // Cambia el texto al español
            }
        });

        // Cambiar el ícono de idioma
        if (language === 'en') {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a inglés
        } else {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a español
        }

        // Guardar la preferencia de idioma en el almacenamiento local
        localStorage.setItem('language', language);
    }

    // Cambiar idioma cuando se haga clic en el ícono de idioma
    languageToggle.addEventListener('click', function () {
        currentLanguage = (currentLanguage === 'es') ? 'en' : 'es';  // Alternar entre español e inglés
        changeLanguage(currentLanguage);
    });

    // Inicializar el idioma al cargar la página
    changeLanguage(currentLanguage);

    // -----------------------------------
    // Cambio de tema (Oscuro/Claro)
    // -----------------------------------

    // Cambiar tema oscuro/claro
    if (currentTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.dataset.theme = 'dark';
        icons.forEach(icon => {
            icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                .replace('icono2.png', 'icono-oscuro2.png')
                .replace('icono3.png', 'icono-oscuro3.png')
                .replace('icono4.png', 'icono-oscuro4.png');
        });
    }

    // Cambiar el tema cuando se hace clic en el ícono
    themeToggle.addEventListener('click', () => {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        const newTheme = isDarkMode ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        themeToggle.dataset.theme = newTheme;

        icons.forEach(icon => {
            if (isDarkMode) {
                icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                    .replace('icono2.png', 'icono-oscuro2.png')
                    .replace('icono3.png', 'icono-oscuro3.png')
                    .replace('icono4.png', 'icono-oscuro4.png');
            } else {
                icon.src = icon.src.replace('icono-oscuro1.png', 'icono1.png')
                    .replace('icono-oscuro2.png', 'icono2.png')
                    .replace('icono-oscuro3.png', 'icono3.png')
                    .replace('icono-oscuro4.png', 'icono4.png');
            }
        });
    });

    // -----------------------------------
    // Menú del perfil
    // -----------------------------------

    // Abrir y cerrar el menú del perfil
    profileIcon.addEventListener('click', function (event) {
        event.stopPropagation();
        profileMenu.style.display = (profileMenu.style.display === 'block') ? 'none' : 'block';
    });

    // Cerrar sesión
    logoutButton.addEventListener('click', function () {
        window.location.href = 'index.html';  // Redirige a la página de inicio
    });

    // Cerrar el menú de perfil si el usuario hace clic fuera de él
    window.addEventListener('click', function (e) {
        if (!profileIcon.contains(e.target) && !profileMenu.contains(e.target)) {
            profileMenu.style.display = 'none';
        }
    });

    // -----------------------------------
    // Calificación del evento
    // -----------------------------------

    // Función para manejar la calificación del evento con estrellas
    const stars = document.querySelectorAll('.star');
    const ratingValue = document.getElementById('rating-value');
    let selectedRating = 0;

    stars.forEach(star => {
        star.addEventListener('click', function () {
            selectedRating = this.getAttribute('data-value');
            ratingValue.textContent = `Calificación: ${selectedRating}`;

            stars.forEach(star => {
                star.classList.toggle('filled', star.getAttribute('data-value') <= selectedRating);
            });
        });
    });

    // -----------------------------------
    // Comentarios del evento
    // -----------------------------------

    // Función para manejar el envío de comentarios
    const submitCommentBtn = document.getElementById('submit-comment');
    const commentInput = document.getElementById('comment');
    const commentsList = document.getElementById('comments-list');

    submitCommentBtn.addEventListener('click', function () {
        const commentText = commentInput.value;
        if (commentText) {
            const newComment = document.createElement('p');
            newComment.textContent = commentText;
            commentsList.appendChild(newComment);
            commentInput.value = '';
        }
    });
});
