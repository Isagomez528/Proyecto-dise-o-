document.addEventListener('DOMContentLoaded', function () {
    const languageToggle = document.querySelector('.custom-icon[alt="idioma"]');  // Ícono de idioma
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    const logoutButton = document.getElementById('logout');
    const themeToggle = document.getElementById('toggle-theme');
    const icons = document.querySelectorAll('.custom-icon');
    
    let currentLanguage = localStorage.getItem('language') || 'es';  // Idioma predeterminado
    const currentTheme = localStorage.getItem('theme') || 'light';  // Tema predeterminado

    // Función para cambiar el idioma
    function changeLanguage(language) {
        const elements = document.querySelectorAll('[data-es], [data-en]');  // Selecciona todos los elementos con texto traducible
        
        elements.forEach(element => {
            const textEs = element.getAttribute('data-es');  // Texto en español
            const textEn = element.getAttribute('data-en');  // Texto en inglés

            if (language === 'en') {
                element.textContent = textEn;  // Cambia el texto al inglés
            } else {
                element.textContent = textEs;  // Cambia el texto al español
            }
        });

        // Cambiar el ícono de idioma
        if (language === 'en') {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a inglés
        } else {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a español
        }

        // Guardar la preferencia de idioma en el almacenamiento local
        localStorage.setItem('language', language);
    }

    // Cambiar idioma cuando se haga clic en el ícono de idioma
    languageToggle.addEventListener('click', function () {
        currentLanguage = (currentLanguage === 'es') ? 'en' : 'es';  // Alternar entre español e inglés
        changeLanguage(currentLanguage);
    });

    // Inicializar el idioma al cargar la página
    changeLanguage(currentLanguage);

    // Cambiar tema oscuro/claro
    if (currentTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.dataset.theme = 'dark';
        icons.forEach(icon => {
            icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                .replace('icono2.png', 'icono-oscuro2.png')
                .replace('icono3.png', 'icono-oscuro3.png')
                .replace('icono4.png', 'icono-oscuro4.png');
        });
    }

    // Cambiar el tema cuando se hace clic en el ícono
    themeToggle.addEventListener('click', () => {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        const newTheme = isDarkMode ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        themeToggle.dataset.theme = newTheme;

        icons.forEach(icon => {
            if (isDarkMode) {
                icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                    .replace('icono2.png', 'icono-oscuro2.png')
                    .replace('icono3.png', 'icono-oscuro3.png')
                    .replace('icono4.png', 'icono-oscuro4.png');
            } else {
                icon.src = icon.src.replace('icono-oscuro1.png', 'icono1.png')
                    .replace('icono-oscuro2.png', 'icono2.png')
                    .replace('icono-oscuro3.png', 'icono3.png')
                    .replace('icono-oscuro4.png', 'icono4.png');
            }
        });
    });

    // Abrir y cerrar el menú del perfil
    profileIcon.addEventListener('click', function (event) {
        event.stopPropagation();
        profileMenu.style.display = (profileMenu.style.display === 'block') ? 'none' : 'block';
    });

    // Cerrar sesión
    logoutButton.addEventListener('click', function () {
        window.location.href = 'index.html';  // Redirige a la página de inicio
    });

    // Cerrar el menú de perfil si el usuario hace clic fuera de él
    window.addEventListener('click', function (e) {
        if (!profileIcon.contains(e.target) && !profileMenu.contains(e.target)) {
            profileMenu.style.display = 'none';
        }
    });

    // Función para calcular el total de horas libres
    function calculateTotalHours() {
        // Seleccionar todas las celdas de horas libres en la tabla
        const hourCells = document.querySelectorAll('.activities-table .activity-hours');
        let totalHours = 0;

        // Sumar los valores de las celdas
        hourCells.forEach(cell => {
            totalHours += parseInt(cell.textContent, 10) || 0; // Convierte el contenido a número y suma
        });

        // Mostrar el total de horas libres
        const totalHoursElement = document.getElementById('total-hours');
        totalHoursElement.textContent = `${totalHours} horas`;

        // Definir el límite de horas
        const requiredHours = 96; // Limite de horas

        // Comprobar si ya se completaron las horas o si se pasó
        const remainingHoursElement = document.getElementById('remaining-hours');
        const messageElement = document.getElementById('message'); // Aquí colocaremos el mensaje

        if (totalHours >= requiredHours) {
            messageElement.textContent = '¡Ya has completado tus horas libres!';
            remainingHoursElement.textContent = ''; // No mostrar horas restantes si ya se completaron
        } else {
            const remainingHours = requiredHours - totalHours;
            messageElement.textContent = 'Aún te faltan horas por completar';
            remainingHoursElement.textContent = `Faltan: ${remainingHours} horas`;
        }
    }

    // Llamar a la función de cálculo al cargar la página
    calculateTotalHours();
});

