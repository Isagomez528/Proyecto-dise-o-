document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    const modal = document.getElementById('event-modal');
    const eventTitleInput = document.getElementById('event-title');
    const saveEventButton = document.getElementById('save-event');
    const cancelEventButton = document.getElementById('cancel-event');
    const deleteEventButton = document.getElementById('delete-event');
    const colorOptions = document.querySelectorAll('.color-option');
    const eventList = document.getElementById('event-list'); // Lista de eventos
    const confirmDeleteModal = document.getElementById('confirm-delete-modal');
    const confirmDeleteButton = document.getElementById('confirm-delete');
    const cancelDeleteButton = document.getElementById('cancel-delete');
    const profileIcon = document.getElementById('profile-icon');
    const profileMenu = document.getElementById('profile-menu');
    const logoutButton = document.getElementById('logout');
    const languageToggle = document.querySelector('.custom-icon[alt="idioma"]');  // Ícono de idioma
    
    let selectedColor = '#FF5733'; // Color predeterminado (naranja)
    let selectedEvent = null;
    let currentLanguage = localStorage.getItem('language') || 'es';  // Idioma predeterminado

    // Recuperar eventos guardados en localStorage
    const savedEvents = JSON.parse(localStorage.getItem('events')) || [];

    // Función para cambiar el idioma
    function changeLanguage(language) {
        const elements = document.querySelectorAll('[data-es], [data-en]');  // Selecciona todos los elementos con texto traducible
        
        elements.forEach(element => {
            const textEs = element.getAttribute('data-es');  // Texto en español
            const textEn = element.getAttribute('data-en');  // Texto en inglés

            if (language === 'en') {
                element.textContent = textEn;  // Cambia el texto al inglés
            } else {
                element.textContent = textEs;  // Cambia el texto al español
            }
        });

        // Cambiar el ícono de idioma
        if (language === 'en') {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a inglés
        } else {
            languageToggle.src = 'Imagenes/icono-oscuro2.png';  // Cambia la imagen del ícono a español
        }

        // Guardar la preferencia de idioma en el almacenamiento local
        localStorage.setItem('language', language);
    }

    // Inicializar el idioma al cargar la página
    changeLanguage(currentLanguage);

    // Cambiar idioma cuando se haga clic en el ícono de idioma
    languageToggle.addEventListener('click', function () {
        currentLanguage = (currentLanguage === 'es') ? 'en' : 'es';  // Alternar entre español e inglés
        changeLanguage(currentLanguage);
    });

    // Inicializar el calendario
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: currentLanguage, // Ajustar el idioma del calendario según la preferencia
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,dayGridWeek,dayGridDay'
        },
        events: savedEvents,
        dateClick: function (info) {
            modal.style.display = 'flex';
            eventTitleInput.value = '';
            deleteEventButton.style.display = 'none';
            modal.setAttribute('data-date', info.dateStr);
            selectedEvent = null;
        },
        eventClick: function (info) {
            modal.style.display = 'flex';
            eventTitleInput.value = info.event.title;
            selectedEvent = info.event;
            deleteEventButton.style.display = 'inline-block';
            modal.setAttribute('data-date', info.event.startStr);
        }
    });

    calendar.render();

    // Funciones relacionadas con el manejo de eventos
    colorOptions.forEach(option => {
        option.addEventListener('click', function () {
            colorOptions.forEach(opt => opt.style.border = '2px solid transparent');
            this.style.border = '2px solid #000';
            selectedColor = this.getAttribute('data-color');
        });
    });

    saveEventButton.addEventListener('click', function () {
        const eventTitle = eventTitleInput.value;
        const eventDate = modal.getAttribute('data-date');

        if (eventTitle) {
            const newEvent = {
                title: eventTitle,
                start: eventDate,
                color: selectedColor
            };

            if (selectedEvent) {
                selectedEvent.setProp('title', eventTitle);
                selectedEvent.setStart(eventDate);
                selectedEvent.setProp('color', selectedColor);
            } else {
                calendar.addEvent(newEvent);
                savedEvents.push(newEvent);
            }

            localStorage.setItem('events', JSON.stringify(savedEvents));

            eventTitleInput.value = '';
            modal.style.display = 'none';

            updateEventList();
        } else {
            alert('Por favor, ingresa un título para el evento.');
        }
    });

    deleteEventButton.addEventListener('click', function () {
        if (selectedEvent) {
            confirmDeleteModal.style.display = 'flex';
        }
    });

    confirmDeleteButton.addEventListener('click', function () {
        if (selectedEvent) {
            selectedEvent.remove();
            const index = savedEvents.findIndex(event => event.start === selectedEvent.startStr && event.title === selectedEvent.title);
            if (index !== -1) {
                savedEvents.splice(index, 1);
                localStorage.setItem('events', JSON.stringify(savedEvents));
            }
            confirmDeleteModal.style.display = 'none';
            modal.style.display = 'none';
            updateEventList();
        }
    });

    cancelDeleteButton.addEventListener('click', function () {
        confirmDeleteModal.style.display = 'none';
    });

    cancelEventButton.addEventListener('click', function () {
        eventTitleInput.value = '';
        modal.style.display = 'none';
    });

    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            eventTitleInput.value = '';
            modal.style.display = 'none';
        }
    });

    window.addEventListener('click', function (e) {
        if (!profileIcon.contains(e.target) && !profileMenu.contains(e.target)) {
            profileMenu.style.display = 'none';
        }
    });

    updateEventList();

    function updateEventList() {
        eventList.innerHTML = '';
        savedEvents.forEach(event => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span class="event-title">${event.title}</span>
                <span class="event-time">${new Date(event.start).toLocaleString()}</span>
                <span class="event-color" style="background-color: ${event.color};"></span>
            `;
            eventList.appendChild(li);
        });
    }

    const themeToggle = document.getElementById('toggle-theme');
    const icons = document.querySelectorAll('.custom-icon');
    const currentTheme = localStorage.getItem('theme') || 'light';

    if (currentTheme === 'dark') {
        document.body.classList.add('dark-mode');
        themeToggle.dataset.theme = 'dark';
        icons.forEach(icon => {
            icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                .replace('icono2.png', 'icono-oscuro2.png')
                .replace('icono3.png', 'icono-oscuro3.png')
                .replace('icono4.png', 'icono-oscuro4.png');
        });
    }

    themeToggle.addEventListener('click', () => {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        const newTheme = isDarkMode ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        themeToggle.dataset.theme = newTheme;

        icons.forEach(icon => {
            if (isDarkMode) {
                icon.src = icon.src.replace('icono1.png', 'icono-oscuro1.png')
                    .replace('icono2.png', 'icono-oscuro2.png')
                    .replace('icono3.png', 'icono-oscuro3.png')
                    .replace('icono4.png', 'icono-oscuro4.png');
            } else {
                icon.src = icon.src.replace('icono-oscuro1.png', 'icono1.png')
                    .replace('icono-oscuro2.png', 'icono2.png')
                    .replace('icono-oscuro3.png', 'icono3.png')
                    .replace('icono-oscuro4.png', 'icono4.png');
            }
        });
    });

    profileIcon.addEventListener('click', function (event) {
        event.stopPropagation();
        profileMenu.style.display = (profileMenu.style.display === 'block') ? 'none' : 'block';
    });

    logoutButton.addEventListener('click', function () {
        window.location.href = 'index.html';
    });
});
